# Changelog


# Unreleased

## Breaking changes

## New features

## Bug fixes


# 1.63.0-1

## Breaking changes

Changed the target platform versions to iOS 11.0 and tvOS 11.0, matching the versions currently targeted by React Native.


# 1.63.0-0

## New features

Upgraded to Boost v1.63.0
